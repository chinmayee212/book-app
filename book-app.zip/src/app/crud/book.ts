export interface Book {
  id: number;
  name: string;
  description: string;
  author: string;
  label: string;
  category: string;
  price: number;
  publication: string;
  year: string;
  edition: string;

}
