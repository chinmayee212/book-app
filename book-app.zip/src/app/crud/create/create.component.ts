import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup , Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CrudService } from '../crud.service';
@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.scss']
})
export class CreateComponent implements OnInit {
  bookForm: FormGroup;
  constructor(public fb: FormBuilder,
              private router: Router,
              public crudService: CrudService) { }

  ngOnInit(): void {
    this.bookForm = this.fb.group({
      name: ['', [Validators.required, Validators.minLength(3)]],
      description: [''],
      author: [''],
      label: [''],
      category: [''],
      price: ['',[Validators.required]],
      publication: ['',[Validators.required]],
      year: ['',[Validators.required]],
      edition: ['', [Validators.required]],
    });
  }
  get name(){
    return this.bookForm.get('name');
  }
  get year(){
    return this.bookForm.get('year');
  }
  get edition(){
    return this.bookForm.get('edition');
  }
  get price(){
    return this.bookForm.get('price');
  }

  submitForm() {
    this.crudService.create(this.bookForm.value).subscribe(res => {
      alert('Created!');
      this.router.navigateByUrl('home');
    });
  }

}
