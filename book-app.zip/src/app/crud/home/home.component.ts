import { Component, OnInit } from '@angular/core';
import { CrudService } from '../crud.service';
import { Book } from '../book';
import {Router} from '@angular/router';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  books: Book[] = [];
  constructor(public crudService: CrudService, private router: Router, ) { }

  ngOnInit(): void {
    this.crudService.getAll().subscribe((data: Book[]) => {
      // console.log(data);
      this.books = data;
    });
  }

  godelete(bookid){
    this.crudService.delete(bookid).subscribe((data) => {
        alert('Please Refresh');
      this.books = this.books.filter(b => b !==  data);

    });
  }

}
