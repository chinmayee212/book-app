var faker =require('faker');

var database ={books: []};
 for(var i=0;i<=10;i++){
	 database.books.push({
		 id:i,
     name:faker.commerce.productName(),
     description: faker.commerce.description(),
      author:faker.commerce.author(),
      label: faker.commerce.label(),
      category: faker.commerce.category(),
      price: faker.commerce.price(),
      publication: faker.commerce.publication(),
      year: faker.commerce.year(),
      edition: faker.commerce.edition(),
	 });
 }
 console.log(JSON.stringify(database));
