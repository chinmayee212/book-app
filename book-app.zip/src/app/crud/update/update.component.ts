import { Component, OnInit } from '@angular/core';
import {Router, ActivatedRoute} from '@angular/router';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {first} from 'rxjs/operators';
import { CrudService } from '../crud.service';
@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.scss']
})
export class UpdateComponent implements OnInit {
  editForm: FormGroup;

  constructor(public fb: FormBuilder,
              private router: Router,
              public crudService: CrudService, private route: ActivatedRoute, ) { }

  ngOnInit(): void {
    const id: number = +this.route.snapshot.paramMap.get('bookId');

    this.crudService.getById(id).subscribe(data => {
      console.log(id);
      this.editForm.setValue(data);
    });


    this.editForm = this.fb.group({
      id:[''],
      name: ['', [Validators.required, Validators.minLength(3)]],
      description: [''],
      author: [''],
      label: [''],
      category: [''],
      price: ['', [Validators.required]],
      publication: ['', [Validators.required]],
      year: ['', [Validators.required]],
      edition: ['', [Validators.required]],
    });

  }

  submitForm() {
    this.crudService.update(this.editForm.value.id, this.editForm.value)
      .pipe(first())
      .subscribe(
        data => {
          alert('Updated!');
          this.router.navigateByUrl('home');
        });
  }
  get name(){
    return this.editForm.get('name');
  }
  get year(){
    return this.editForm.get('year');
  }
  get edition(){
    return this.editForm.get('edition');
  }
  get price(){
    return this.editForm.get('price');
  }

}
